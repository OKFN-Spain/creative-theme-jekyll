# Tema Creative para Jekyll utilizado para madrid.opendataday.org

Una implementación para Jekyll del tema de [Creative Theme](http://startbootstrap.com/template-overviews/creative/) con plantilla de [Start Bootstrap](http://startbootstrap.com).

*Creative* es un tema base para realizar proyectos de diversos tipos. Incluye muchas posibilidades y plugins de tal manera que puedes utilizarlo como un buen recurso para proyectos que quieran usar *Jekyll*

El original lo puedes ver en acción en <https://volny.github.io/creative-theme-jekyll/>

## Adaptación OKFNes

- Hemos *forkeado* el tema en nuestra cuenta de *GitHub*.
- Luego lo clonamos con `git clone URL` en tu espacio de trabajo.
- Editamos `_config.yml` para la configuración del sitio.
- En `_layouts/front.html` está el *html* que hemos de tocar para reorganizar las secciones que contiene la web a través del directorio `includes`, para borrar las que existen o para crear nuevas.

